
vdhcoapp is an application providing the Video DownloadHelper add-on browser with:

- file access features that are not available from the browser
- a build of the ffmpeg video converter

vdhcoapp complies to the native messaging protocol (https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Native_messaging) 
and is not intended to be used directly from the command line.

vdhcoapp is free software under the Gnu Public License v2.0. Source code can be obtained from
https://github/com/mi-g/vdhcoapp or as snapshot from https://github.com/mi-g/vdhcoapp/releases
